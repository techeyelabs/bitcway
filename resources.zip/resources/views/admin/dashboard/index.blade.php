@extends('admin.layouts.main')

@section('custom_css')

@endsection
@section('content')

    <div id="wrap">
        <h2>Dashboard</h2>
        <hr>
    </div>


@endsection

@section('custom_js')

@endsection
