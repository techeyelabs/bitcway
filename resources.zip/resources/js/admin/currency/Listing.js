import AppListing from '../app-components/Listing/AppListing';

Vue.component('currency-listing', {
    mixins: [AppListing]
});